package com.controle;

import java.util.ArrayList;

import com.model.Produto;


public interface AtualizarCesta {
	
     public void atualizarCesta(ArrayList<Produto> produtos);

}
