package com.controle.rbc;

import java.util.ArrayList;

import com.model.Produto;

public class Recomendar {
	
	private double similaridade ;
	private double caso_mais_similar;
	ArrayList<Produto> produtos_recomendados = new ArrayList<Produto>();
	
    /*Calcula a similaridade entre os codigos dos produtos através do algoritimo da distancia euclidiana.
     * Acessa os casos da base de casos, e calcula a similaridade do atributo codigo de cada produto,
     * com o codigo dos produtos da cesta do cliente.
     * O caso que apresentar a menor distancia sera retornado a sua solução(array de produtos(obs.: 
     * por enquanto so sera recomendado um produto))
     * */ 
	public ArrayList<Produto> calcularSimilaridade(BaseDeCasos base, ArrayList<Produto> cesta_do_cliente){
			
		for(int i=0; i<base.getBase().size();i++){
			similaridade = 0;
			for (int ii =0; ii<base.getBase().get(i).getCesta().size();ii++){
				similaridade +=(Math.pow(base.getBase().get(i).getCesta().get(ii).getCodigo(),2)-
				(Math.pow(cesta_do_cliente.get(ii).getCodigo(),2)));					
			}
					
			if (i == 0){
				caso_mais_similar =  Math.sqrt(similaridade);
			    produtos_recomendados = base.getBase().get(i).getSolucao();			   
			}
			
			if (Math.sqrt(similaridade) < caso_mais_similar){
				caso_mais_similar = Math.sqrt(similaridade);
				produtos_recomendados = base.getBase().get(i).getSolucao();		   
			}    		

		}
		//Solução do caso mais similar(array de produtos solucao).
		return produtos_recomendados;
		
	}
}
