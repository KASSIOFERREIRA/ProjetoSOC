package com.controle.rbc;

import java.util.ArrayList;


import com.model.Produto;

public class Caso {
	
    private ArrayList<Produto> cesta; 
    private ArrayList<Produto> solucao;  
    private boolean avaliacao;
    
    public Caso (){
    	this.cesta = new ArrayList<Produto>();
    	this.solucao =  new ArrayList<Produto>();
    	
    }
    
    public ArrayList<Produto> getCesta(){
    	return this.cesta;
    }
    
    public ArrayList<Produto> getSolucao(){
    	return this.solucao;
    }
    
    public void setAvaliacao(boolean avaliacao){
    	this.avaliacao = avaliacao;
    }
                                           
}
