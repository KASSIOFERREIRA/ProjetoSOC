package com.controle.rbc;

import java.util.ArrayList;
// Como nao tem banco esta classe sera o banco de casos.
public class BaseDeCasos {
    private ArrayList<Caso> base;
    
    public BaseDeCasos(){
    	this.base = new ArrayList<Caso>();
    }
    
    
    public ArrayList<Caso> getBase(){
    	return this.base;
    }
    
    
}
