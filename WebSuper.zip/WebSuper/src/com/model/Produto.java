package com.model;


import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public abstract class Produto {
	private String nome;
	private double preco;
	private String marca;
	private int codigo;
	
	public Produto(String nome, String marca, double preco, int codigo){
		this.nome = nome;
		this.marca = marca;	
		this.preco = preco;
		this.codigo = codigo;
	}
	
    
	public int getCodigo(){
		return codigo;
	}

	@Override
	public String toString() {
		return " Produto: " + nome + "\n Preço: " + preco + "\n Marca: "
				+ marca + "\n Código: " + codigo + "\n";
	}
    
    
}
