package com.model;

import java.util.ArrayList;


public class Cliente {
	
	private ArrayList<Produto> cesta_do_cliente;
	private String nome ;
	private int id;
	
	
	
	public Cliente(String nome, int id){
		this.nome= nome;
		this.id = id ;
	    this.cesta_do_cliente = new ArrayList<Produto>();
		
	}
	
	
	
	public ArrayList<Produto> getCesta(){
		return this.cesta_do_cliente;
	}
	
	public void setCesta(ArrayList<Produto> cesta_do_cliente){
		this.cesta_do_cliente=cesta_do_cliente;
	} 



	@Override
	public String toString() {
		return "CLIENTE: Nome: "
				+ nome + ", id: " + id + "\n \n"+"CESTA DO CLIENTE:\n" + cesta_do_cliente ;
	}
}
