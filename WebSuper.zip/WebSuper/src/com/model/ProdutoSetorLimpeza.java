package com.model;

import java.util.ArrayList;

import javax.xml.bind.annotation.XmlRootElement;

import com.controle.AtualizarCesta;

@XmlRootElement
public class ProdutoSetorLimpeza extends Produto implements AtualizarCesta{

	public ProdutoSetorLimpeza(String nome, String marca, double preco,int codigo) {
		super(nome, marca, preco, codigo);
		
	}

	@Override
	public void atualizarCesta(ArrayList<Produto> produtos) {
		this.atualizarCesta(produtos);	
		
	}

	

	

}
