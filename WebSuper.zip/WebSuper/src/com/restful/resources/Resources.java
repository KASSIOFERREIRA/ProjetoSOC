package com.restful.resources;

import java.util.ArrayList;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

import org.codehaus.jettison.json.JSONObject;

import com.controle.rbc.BaseDeCasos;
import com.controle.rbc.Caso;
import com.controle.rbc.Recomendar;
import com.model.Cliente;
import com.model.Produto;
import com.model.ProdutoSetorAlimentos;
import com.sun.jersey.json.impl.provider.entity.JSONObjectProvider;

@Path("/super")
public class Resources{
	static BaseDeCasos base = new BaseDeCasos();;
	static Cliente cliente = new Cliente("Joao", 100);
	Cliente cliente2 = new Cliente("Jeillysson",101);
	boolean avaliacao1 = true;
	boolean avaliacao2 = false;
	
	Produto p1 = new ProdutoSetorAlimentos("macarrao", "pilar", 1.35, 1001);
	Produto p2 = new ProdutoSetorAlimentos("presunto", "quero", 2.35, 1002);
	Produto p3 = new ProdutoSetorAlimentos("salsicha", "sadia", 5.35, 1003);
	Produto p4 = new ProdutoSetorAlimentos("presunto", "aurora", 3.35, 1004);
	Produto p5 = new ProdutoSetorAlimentos("feijão preto", "urbano", 5.35, 1005);
	Produto p6 = new ProdutoSetorAlimentos("tomate", "Da terra", 6.35, 1006);
	Produto p7 = new ProdutoSetorAlimentos("banana", "Do pé", 5.35, 1007);
	Produto p8 = new ProdutoSetorAlimentos("massa para lazanha", "pilar", 2.35, 1008);
	Produto p9 = new ProdutoSetorAlimentos("macarrao", "pilar", 1.35, 1009);
	Produto p10 = new ProdutoSetorAlimentos("farinha", "branca", 2.35, 1010);
	Produto p11 = new ProdutoSetorAlimentos("ervilha", "erviral", 2.25, 1011);
	Produto p12= new ProdutoSetorAlimentos("milho verde", "erviral", 2.35, 1012);
	Produto p13 = new ProdutoSetorAlimentos("suco ades uva", "ades", 7.35, 1013);
	Produto p14= new ProdutoSetorAlimentos("calabresa", "perdigão", 10.35, 1014);
	Produto p15= new ProdutoSetorAlimentos("cuzcuz", "coringa", 1.95, 1015);
	Produto p16 = new ProdutoSetorAlimentos("molho tomate", "quero", 1.55, 1016);
	Produto p17 = new ProdutoSetorAlimentos("queijo", "Da vaca", 2.35, 1017);
	Produto p18 = new ProdutoSetorAlimentos("arroz", "Tio vieira", 2.55, 1018);
	Produto p19 = new ProdutoSetorAlimentos("pão", "françes", 5.55, 1019);
		
		
	
	
		@GET
		@Produces("text/plain")
		public String gerarBase(){
						
		  /* Cada caso é composto por:
		  * Problema: que é a cesta do cliente com os produtos;
		  * Solucao: que é são os produtos recomendados ao cliente de acordo com sua cesta;
		  * Avaliação: verificacao se o cliente comprou o produto recomendado; 
		  */
		  		
		//=======================================================================//
		// Caso1
		Caso c1 = new Caso();
		// Cesta1
		c1.getCesta().add(p13);
		c1.getCesta().add(p16);
		
		//Solucao de acordo com a cesta do cliente.(Produto recomendado).		
		c1.getSolucao().add(p17);
			
		// Avaliacao se o cliente comprou ou não o produto recomendado.		
		
		c1.setAvaliacao(avaliacao1);
		
		//Adicionando caso, na base de Casos
		base.getBase().add(c1);
		//========================================================================// 
		
		
		//=======================================================================//
		// Caso2
		Caso c2 = new Caso();			
		c2.getCesta().add(p5);
		c2.getCesta().add(p14);	
		c2.getSolucao().add(p18);		
		c2.setAvaliacao(avaliacao1);	
		base.getBase().add(c2);				
		//========================================================================// 
		
		// Caso3
		Caso c3 = new Caso();			
		c3.getCesta().add(p1);
		c3.getCesta().add(p2);	
		c3.getSolucao().add(p16);		
		c3.setAvaliacao(avaliacao1);	
		base.getBase().add(c3);				
		//========================================================================// 
		
		// Caso4
		Caso c4 = new Caso();			
		c4.getCesta().add(p10);
		c4.getCesta().add(p5);	
		c4.getSolucao().add(p14);		
		c4.setAvaliacao(avaliacao1);	
		base.getBase().add(c4);				
		//========================================================================// 
		
		// Caso5
		Caso c5 = new Caso();			
		c5.getCesta().add(p2);
		c5.getCesta().add(p19);	
		c5.getSolucao().add(p13);		
		c5.setAvaliacao(avaliacao1);	
		base.getBase().add(c5);				
		//========================================================================// 				
				
		return "Os Produtos que temos sao:  \n"
		+ "FEIJAO: \n"
		+ "ARROZ: \n"
		+ "MACARRAO: \n"
		+ "CUZCUZ: \n"
		+ "CARNE MOIDA: \n"
		+ "FARINHA: \n"
		+ "ERVILHA: \n"
		+ "MASSA PARA LASANHA: \n"
		+ "SABONETE: \n"
		+ "LEITE EM PO: \n"
		+ "SUCO - ADES - SABOR LARANJA: \n"
		+ "SUCO - ADES - SABOR MACA: \n"
		+ "SUCO - ADES - SABOR UVA:\n"
		+ "\n";	
		
	}
		
   
	
	@Path("{id}")
	@GET
	@Produces("text/plain")
	public String getNovaRecomendacao(@PathParam("id") int id) {
		ArrayList<Produto> cesta = new ArrayList<Produto>();
		
		if (id == 1){
			cesta.add(p1);
			cesta.add(p2);
			cliente.setCesta(cesta);
			return 
			    cliente.toString() + "\n"
			    +"\n";			
		}
		
		if (id == 2){	
			cesta.add(p8);
			cesta.add(p3);
			cliente.setCesta(cesta);		
			return 
			    cliente.toString() + "\n"
			    +"\n";		
		}
		
		return "";		
		
	}
	
	 // Acessar produto recomendado
		@Path("/produto")
		@GET
		@Produces("text/plain")
		public String getProduto() {
			String p ="";
			/* Chamando o metodo da classe Recomendar e seu retorno sera um array de produtos con
			tendo os produtos recomendados*/
			for(Produto produto : new Recomendar().calcularSimilaridade(base,cliente.getCesta())){
				p+= produto.toString();
							
			}
			return 
			    cliente.toString() + "\n"
			    +"\n"+
				"PRODUTO RECOMENDADO:\n"
				+ "\n" 
				+p+"\n";
		}
	
	
	
		
		
		
	
}
